#ifndef _GAME_H
#define _GAME_H

#include "Framework\timer.h"
#include "general.h"
#include "enemy.h"
#include "character.h"
#include <vector>

extern CStopWatch g_swTimer;
extern bool g_bQuitGame;

extern std::vector<SGameEnemy> g_sEnemy;
extern double g_dBounceTimeEnemy;

extern SGameChar g_sChar;

extern double g_dGunFireTime;

extern std::vector<SBullet> g_sCharBullets;
extern std::vector<COORD> g_sCharShotgunBullets;
extern std::vector<SBullet> g_sEnemyBullets;

void init        ( void );      // initialize your variables, allocate memory, etc
void getInput    ( void );      // get input from player
void update      ( double dt ); // update the game and the state of the game
void render      ( void );      // renders the current state of the game to the console
void shutdown    ( void );      // do clean up, free memory

void splashScreenWait();    // waits for time to pass in splash screen
void winScreenWait();		// waits for player to press space in win screen
void loseScreenWait();		// waits for player to press space in lose screen
void gameplay();            // gameplay logic
void checkIfLose();
void moveCharacter();       // moves the character, collision detection, physics, etc
void shotgunAttack();
void processUserInput();    // checks if you should change states or do something else with the game, e.g. pause, exit
void clearScreen();         // clears the current screen and draw from scratch 
void renderSplashScreen();  // renders the splash screen
void renderWinScreen();		// renders the winning screen when player completes the objective
void renderLoseScreen();	// renders the losing screen when player dies
void renderGame();          // renders the game stuff
void renderMap();           // renders the map to the buffer first
void renderCharacter();     // renders the character into the buffer
void renderFramerate();     // renders debug information, frame rate, elapsed time, etc
void renderToScreen();      // dump the contents of the buffer to the screen, one frame worth of game
bool checkCoordinates(int _inputX, int _inputY);
int getCharInMap(COORD _position); // Returns the character in the position in map 1
void moveBullets();
int ifBulletHitEnemy(COORD _cBulletCOORD, int _dmg);
#endif // _GAME_H