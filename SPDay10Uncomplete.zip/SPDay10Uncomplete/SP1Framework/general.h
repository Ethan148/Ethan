#ifndef _GENERAL_H
#define _GENERAL_H

#include <windows.h>

// Define the structs / enums used in the other files

// Enumeration to store the control keys that your game will have
enum EKEYS
{
	K_UP,
	K_DOWN,
	K_LEFT,
	K_RIGHT,
	K_ESCAPE,
	K_SPACE,
	K_ONE,
	K_TWO,
	K_THREE,
	K_FOUR,
	K_COUNT
};

// Enumeration for the different screen states
enum EGAMESTATES
{
	S_SPLASHSCREEN,
	S_GAME,
	S_WIN,
	S_LOSE,
	S_COUNT
};

enum EDIRECIONS
{
	S_UP,
	S_DOWN,
	S_LEFT,
	S_RIGHT,
	S_NORTHEAST,
	S_NORTHWEST,
	S_SOUTHEAST,
	S_SOUTHWEST
};

enum EWEAPONS
{
	S_PISTOL,
	S_SHOTGUN
};

enum EPOWERUPS
{
	SPEED_UP,
	ADD_LIVES,
	PAINT_BUCKET,
	SHOTGUN,
};

// struct for the game character
struct SGameChar
{
	COORD m_cLocation;
	bool  m_bActive;
	EDIRECIONS m_eDirection;
	EWEAPONS m_eWeapon = S_PISTOL;
	bool m_bHasSpeedUp;
	double m_dSpeedUpPickUpTime;
	int m_iHealth;
	int m_iPaint;
	int m_iShotgunAmmo;
};

struct SGameEnemy
{
	COORD m_cLocation;
	bool  m_bActive; // If the enemy is shooting then its true
	EDIRECIONS m_eDirection;
	// Enemey type | Movement | When it attacks          | How it attacks 
	// 1           | Random      | Empty (since melee)   | Melee
	// 2           | Random      | When it spots player  | Ranged (Pistol)
	// 3           | No Movement | Infinite (constantly) | Ranged (Pistol)
	int m_iEnemyType; 
	int m_iHealth = 3; // starting health of the enemy is 3
	double m_dFireTime; // Firing time when the enemy fires a bullet
};

struct SBullet
{
	COORD m_cLocation = { 0,0 };
	EDIRECIONS m_eDirection;
	double m_dBounceTime;
};

struct SPowerUp
{
	COORD m_cLocation;
	EPOWERUPS m_ePowerUp;
};

#endif // _GENERAL_H
