// This is the main file for the game logic and function
//
//
#include "game.h"
#include "Framework\console.h"
#include <iostream>
#include <iomanip>
#include <sstream>
#include <fstream>
#include <ctime>

// Virtual keys for numbers 1,2,3 at the top of the keyboard
#define VK_ONE            0x31
#define VK_TWO            0x32
#define VK_THREE          0x33
#define VK_FOUR           0x34

double  g_dElapsedTime;
double  g_dDeltaTime;
bool    g_abKeyPressed[K_COUNT];

bool g_bCheckLife = false;

int soundLayer;

// Set it to be -6 at the start because the code for the death animation will check
// if (enemyDiedTime >= g_dElapsedTime - 5.0)
// and it will run if the enemy is set more than equal to -5.0
double enemyDiedTime = -6.0; 
COORD enemyDiedPos;

std::vector<SPowerUp> g_sPowerUps;

COORD g_cPortals[2];

// Game specific variables here

EGAMESTATES g_eGameState = S_SPLASHSCREEN;
int g_iLevelNum; // shows the game level
double  g_dBounceTime; // this is to prevent key bouncing, so we won't trigger keypresses more than once
double g_dhighScores[3][5] = {}; // highScores[2][3] is the 3rd highest highscore for stage 2

int g_iNumOfEmptySpace; // stores the number of empty spaces in the original map file

int g_iWidthOfMap;

//Collectable (Paint , weapons?? ,lives,speed)

// Console object
Console g_Console(101, 30, "SP1 Framework");

// Map
// What the numbers represent and what they show in the map
// Numbers | What they represent | Character it is in buffer | Character in ASCII | 
// 0       | empty spaces        | <spaces>                  | 32                 | 
// 1       | walls               | solid block               | 219                | 
// 10      | paint               | a dot                     | 249                |
int g_iMap[24][73] = {};

//--------------------------------------------------------------
// Purpose  : Initialisation function
//            Initialize variables, allocate memory, load data from file, etc. 
//            This is called once before entering into your main loop
// Input    : void
// Output   : void
//--------------------------------------------------------------
void init(void)
{
	// Set precision for floating point output
	//g_dElapsedTime = 0.0;
	g_dBounceTime = 0.0;
	g_dBounceTimeEnemy = 0.0;

	// sets the initial state for the game
	g_eGameState = S_SPLASHSCREEN;

	g_sChar.m_cLocation.X = 1;
	// starting Y value for the character will be assigned later
	g_sChar.m_bActive = true;
	g_sChar.m_eDirection = S_UP;
	
	// sets the width, height and the font name to use in the console
	g_Console.setConsoleFont(0, 16, L"Consolas");
}

//--------------------------------------------------------------
// Purpose  : Reset before exiting the program
//            Do your clean up of memory here
//            This is called once just before the game exits
// Input    : Void
// Output   : void
//--------------------------------------------------------------
void shutdown(void)
{
	// Reset to white text on black background
	colour(FOREGROUND_BLUE | FOREGROUND_GREEN | FOREGROUND_RED);

	g_Console.clearBuffer();
}

//--------------------------------------------------------------
// Purpose  : Reset all the variables when a level is over
//			  This is called when the level changes to either the WIN screen or the LOSE screen
//			  Put all the variables that needs to be reset here (e.g. time, coordinates, etc)
// Input    : Void
// Output   : void
//--------------------------------------------------------------
void reset(void)
{
	std::srand(g_dElapsedTime); // use current elapsed time as seed for random generator
	g_dElapsedTime = 0.0;
	g_dBounceTime = 0.0;
	g_dBounceTimeEnemy = 0.0;

	// Resetting character variables
	g_sChar.m_cLocation.X = 1;
	// Y value for the character will be set later (since it depends on the map)
	g_sChar.m_eWeapon = S_PISTOL;
	g_sChar.m_bHasSpeedUp = false;
	g_sChar.m_dSpeedUpPickUpTime = 0.0;
	g_sChar.m_iHealth = 2;
	g_sChar.m_iPaint = 0;

	// Clearing the vectors
	g_sEnemy.clear();
	g_sEnemyBullets.clear();
	g_sCharBullets.clear();
	g_sPowerUps.clear();

	g_sChar.m_iShotgunAmmo = 0;

	g_dGunFireTime = 0.0;
	
	g_iWidthOfMap = 0;
}

//--------------------------------------------------------------
// Purpose  : Getting all the key press states
//            This function checks if any key had been pressed since the last time we checked
//            If a key is pressed, the value for that particular key will be true
//
//            Add more keys to the enum in game.h if you need to detect more keys
//            To get other VK key defines, right click on the VK define (e.g. VK_UP) and choose "Go To Definition" 
//            For Alphanumeric keys, the values are their ascii values (uppercase).
// Input    : Void
// Output   : void
//--------------------------------------------------------------
void getInput(void)
{
	g_abKeyPressed[K_UP] = isKeyPressed(VK_UP);
	g_abKeyPressed[K_DOWN] = isKeyPressed(VK_DOWN);
	g_abKeyPressed[K_LEFT] = isKeyPressed(VK_LEFT);
	g_abKeyPressed[K_RIGHT] = isKeyPressed(VK_RIGHT);
	g_abKeyPressed[K_SPACE] = isKeyPressed(VK_SPACE);
	g_abKeyPressed[K_ESCAPE] = isKeyPressed(VK_ESCAPE);
	// If either the number in the number pad is pressed or the number in the numbers is pressed, then g_abKeyPressed for that number is true
	g_abKeyPressed[K_ONE] = isKeyPressed(VK_NUMPAD1) || isKeyPressed(VK_ONE);
	g_abKeyPressed[K_TWO] = isKeyPressed(VK_NUMPAD2) || isKeyPressed(VK_TWO);
	g_abKeyPressed[K_THREE] = isKeyPressed(VK_NUMPAD3) || isKeyPressed(VK_THREE);
	g_abKeyPressed[K_FOUR] = isKeyPressed(VK_NUMPAD4) || isKeyPressed(VK_FOUR);
}

//--------------------------------------------------------------
// Purpose  : Update function
//            This is the update function
//            double dt - This is the amount of time in seconds since the previous call was made
//
//            Game logic should be done here.
//            Such as collision checks, determining the position of your game characters, status updates, etc
//            If there are any calls to write to the console here, then you are doing it wrong.
//
//            If your game has multiple states, you should determine the current state, and call the relevant function here.
//
// Input    : dt = deltatime
// Output   : void
//--------------------------------------------------------------
void update(double dt)
{
	// get the delta time
	g_dElapsedTime += dt;
	g_dDeltaTime = dt;

	switch (g_eGameState)
	{
	case S_SPLASHSCREEN: splashScreenWait(); // game logic for the splash screen
		break;
	case S_GAME:
		gameplay(); // gameplay logic when we are in the game
		moveEnemy();
		moveBullets();
		//checkIfLose();
		break;
	case S_WIN: winScreenWait();
		break;
	case S_LOSE: loseScreenWait();
		break;
	}
}
//--------------------------------------------------------------
// Purpose  : Render function is to update the console screen
//            At this point, you should know exactly what to draw onto the screen.
//            Just draw it!
//            To get an idea of the values for colours, look at console.h and the URL listed there
// Input    : void
// Output   : void
//--------------------------------------------------------------
void render()
{
	clearScreen();      // clears the current screen and draw from scratch 
	switch (g_eGameState)
	{
	case S_SPLASHSCREEN: renderSplashScreen();
		break;
	case S_GAME: renderGame();
		break;
	case S_WIN: renderWinScreen();
		break;
	case S_LOSE: renderLoseScreen();
		break;
	}
	renderFramerate();  // renders debug information, frame rate, elapsed time, etc
	renderToScreen();   // dump the contents of the buffer to the screen, one frame worth of game
}

void splashScreenWait()    // waits for time to pass in splash screen
{
	std::string mapFileName;

	bool bKeyPressed = 0;

	if (g_abKeyPressed[K_ONE])
	{
		bKeyPressed = 1;
		g_iLevelNum = 1;
		mapFileName = "lvlOneMap.txt";
		g_eGameState = S_GAME;
	}
	else if (g_abKeyPressed[K_TWO])
	{
		bKeyPressed = 1;
		g_iLevelNum = 2;
		mapFileName = "lvlTwoMap.txt";
		g_eGameState = S_GAME;
	}
	else if (g_abKeyPressed[K_THREE])
	{
		bKeyPressed = 1;
		g_iLevelNum = 3;
		mapFileName = "lvlThreeMap.txt";
		g_eGameState = S_GAME;
	}
	else if (g_abKeyPressed[K_FOUR])
	{
		bKeyPressed = 1;
		g_iLevelNum = 4;
		mapFileName = "lvlFourMap.txt";
		g_eGameState = S_GAME;
	}

	if (bKeyPressed)
	{
		reset();

		std::ifstream mapFile(mapFileName);

		std::string rowText = "";

		SGameEnemy sEnemy;
		SPowerUp sPowerUp;

		// Transferring the map file into a array of string
		for (int row = 0; row < 24; ++row)
		{
			getline(mapFile, rowText);
			for (int col = 0; col < 73; ++col)
			{
				// Add new cases for enemies, powerups, etc
				// <spaces> are empty spaces
				// '#' are walls
				// characters a-e are enemies
				// 'Q' is the speed power-up
				// 'P' is the add lives power-up
				// 'M' is the attacking power-up
				switch (rowText[col])
				{
				case ' ':g_iMap[row][col] = 0;  break;
				case '#':g_iMap[row][col] = 1;  break;
				case 'S':
					sPowerUp.m_cLocation.X = col;
					sPowerUp.m_cLocation.Y = row + 1;
					sPowerUp.m_ePowerUp = SPEED_UP;
					g_sPowerUps.push_back(sPowerUp);
					break;
				case 'L':
					sPowerUp.m_cLocation.X = col;
					sPowerUp.m_cLocation.Y = row + 1;
					sPowerUp.m_ePowerUp = ADD_LIVES;
					g_sPowerUps.push_back(sPowerUp);
					break;
				case 'B':
					sPowerUp.m_cLocation.X = col;
					sPowerUp.m_cLocation.Y = row + 1;
					sPowerUp.m_ePowerUp = PAINT_BUCKET;
					g_sPowerUps.push_back(sPowerUp);
					break;
				case 'A':
					sPowerUp.m_cLocation.X = col;
					sPowerUp.m_cLocation.Y = row + 1;
					sPowerUp.m_ePowerUp = SHOTGUN;
					g_sPowerUps.push_back(sPowerUp);
					break;
				case '1':
					g_cPortals[0].X = col;
					g_cPortals[0].Y = row + 1;
					break;
				case '2':
					g_cPortals[1].X = col;
					g_cPortals[1].Y = row + 1;
					break;
					
				case 'a':
					// Type 1 enemy
					// If there is 'a' in the map, add it to g_sEnemy with its type to be 1
					sEnemy.m_cLocation.X = col;
					sEnemy.m_cLocation.Y = row;
					sEnemy.m_eDirection = S_UP; // Set the default direction of the enemy to be up
					sEnemy.m_iEnemyType = 1;
					sEnemy.m_bActive = false;
					g_sEnemy.push_back(sEnemy);
					break;
					
				case 'b':
					// Type 2 enemy
					// If there is 'b' in the map, add it to g_sEnemy with its type to be 2
					sEnemy.m_cLocation.X = col;
					sEnemy.m_cLocation.Y = row;
					sEnemy.m_eDirection = S_UP; // Set the default direction of the enemy to be up
					sEnemy.m_iEnemyType = 2;
					sEnemy.m_bActive = false;
					g_sEnemy.push_back(sEnemy);
					break;
					
				case '>':
					// Type 3 enemy
					sEnemy.m_cLocation.X = col;
					sEnemy.m_cLocation.Y = row;
					sEnemy.m_eDirection = S_RIGHT; // Follow the direction of the arrow
					sEnemy.m_iEnemyType = 3;
					sEnemy.m_bActive = false;
					g_sEnemy.push_back(sEnemy);
					break;
				case '=':
					// Boss
					sEnemy.m_cLocation.X = col;
					sEnemy.m_cLocation.Y = row;
					sEnemy.m_eDirection = S_UP;
					sEnemy.m_iEnemyType = 4;
					sEnemy.m_bActive = false;
					g_sEnemy.push_back(sEnemy);
					break;
				}
			}
		}

		// Setting the player's starting Y position
		for (int row = 23; ; --row)
		{
			if (g_iMap[row][0] == 1)
			{
				g_sChar.m_cLocation.Y = row;
				break;
			}
		}

		switch (g_iLevelNum)
		{
		case 1: g_iNumOfEmptySpace = 606; break;
		case 2: g_iNumOfEmptySpace = 428; break;
		case 3: g_iNumOfEmptySpace = 974; break;
		case 4: g_iNumOfEmptySpace = 767; break;
		}

		// Getting the width of the map
		for (int iPos = 0; iPos < 73; iPos++)
		{
			if (g_iMap[0][iPos] == 0)
			{
				break;
			}
			else 
			{
				++g_iWidthOfMap;
			}
		}
	}
}

void winScreenWait()
{
	if (g_abKeyPressed[K_SPACE])
	{
		g_eGameState = S_SPLASHSCREEN;
	}
}

void loseScreenWait()
{
	if (g_abKeyPressed[K_SPACE])
	{
		g_eGameState = S_SPLASHSCREEN;
	}
}

void gameplay()            // gameplay logic
{
	processUserInput(); // checks if you should change states or do something else with the game, e.g. pause, exit
	moveCharacter();    // moves the character, collision detection, physics, etc
						// sound can be played here too.
}

void processUserInput()
{
	// quits the game if player hits the escape key
	if (g_abKeyPressed[K_ESCAPE])
		g_bQuitGame = true;
}

void clearScreen()
{
	// Clears the buffer with this colour attribute
	g_Console.clearBuffer(0x70);
}

void renderSplashScreen()  // renders the splash screen
{
	COORD c = g_Console.getConsoleSize();
	c.Y /= 3;
	c.X = c.X / 2 - 9;
	g_Console.writeToBuffer(c, "A game in 3 seconds", 0x70);
	c.Y += 1;
	c.X = g_Console.getConsoleSize().X / 2 - 11;
	g_Console.writeToBuffer(c, "Press <Space> to shoot", 0x70);
	c.Y += 1;
	c.X = g_Console.getConsoleSize().X / 2 - 9;
	g_Console.writeToBuffer(c, "Press 'Esc' to quit", 0x70);
	c.Y += 2;
	c.X = g_Console.getConsoleSize().X / 2 - 12;
	g_Console.writeToBuffer(c, "Press 1 to go to level 1", 0x70);
	c.Y += 1;
	g_Console.writeToBuffer(c, "Press 2 to go to level 2", 0x70);
	c.Y += 1;
	g_Console.writeToBuffer(c, "Press 3 to go to level 3", 0x70);
	c.Y += 1;
	c.X = g_Console.getConsoleSize().X / 2 - 15;
	g_Console.writeToBuffer(c, "Press 4 to go to level 4 (BOSS)", 0x70);
	c.Y += 2;
	c.X = g_Console.getConsoleSize().X / 2 - 20;
	g_Console.writeToBuffer(c, "Press 1 to change your weapon to pistol", 0x70);
	c.Y += 1;
	c.X = g_Console.getConsoleSize().X / 2 - 20;
	g_Console.writeToBuffer(c, "Press 2 to change your weapon to shotgun", 0x70);
}

void renderWinScreen()
{
	std::ostringstream ss;
	COORD c;
	ss << std::fixed << std::setprecision(3);
	c.Y = 2;
	c.X = g_Console.getConsoleSize().X / 2 - 5;
	g_Console.writeToBuffer(c, "Highscores", 0x70);

	ss.str("");
	ss << "Level " << g_iLevelNum;
	c.X = g_Console.getConsoleSize().X / 2 - 3;
	c.Y += 1;
	g_Console.writeToBuffer(c, ss.str(), 0x70);

	// Displays all the high scores
	ss.str("");
	ss << "1. " << g_dhighScores[g_iLevelNum][0];
	c.X = 35;
	c.Y += 1;
	g_Console.writeToBuffer(c, ss.str(), 0x70);

	ss.str("");
	ss << "2. " << g_dhighScores[g_iLevelNum][1];
	c.Y += 1;
	g_Console.writeToBuffer(c, ss.str(), 0x70);

	ss.str("");
	ss << "3. " << g_dhighScores[g_iLevelNum][2];
	c.Y += 1;
	g_Console.writeToBuffer(c, ss.str(), 0x70);

	ss.str("");
	ss << "4. " << g_dhighScores[g_iLevelNum][3];
	c.Y += 1;
	g_Console.writeToBuffer(c, ss.str(), 0x70);

	ss.str("");
	ss << "5. " << g_dhighScores[g_iLevelNum][4];
	c.Y += 1;
	g_Console.writeToBuffer(c, ss.str(), 0x70);

	c.Y += 3;
	c.X = g_Console.getConsoleSize().X / 2 - 18;
	g_Console.writeToBuffer(c, "Press <Space> to go to splash screen", 0x70);
}

void renderLoseScreen()
{
	COORD c = g_Console.getConsoleSize();
	c.Y /= 3;
	c.X = c.X / 2 - 4;
	g_Console.writeToBuffer(c, "You Lose!", 0x70);
	c.Y += 3;
	c.X = g_Console.getConsoleSize().X / 2 - 18;
	g_Console.writeToBuffer(c, "Press <Space> to go to splash screen", 0x70);

}

void renderGame()
{
	renderMap();        // renders the map to the buffer first
	renderCharacter();  // renders the character into the buffer
}

void renderMap()
{	
	int numOfPixelsColored = 0;

	std::string rowText = "";

	// Set up sample colours, and output shadings
	const WORD colors[] = {
		0x1A, 0x2B, 0x3C, 0x4D, 0x5E, 0x6F,
		0xA1, 0xB2, 0xC3, 0xD4, 0xE5, 0xF6
	};

	COORD c;
	c.X = 0;
	c.Y = 0;
	for (int row = 0; row < 24; ++row)
	{
		rowText = "";
		for (int col = 0; col < 73; ++col)
		{
			switch (g_iMap[row][col])
			{
			case 0: rowText += 32;  break;
			case 1: rowText += 219; break;
			case 10: 
				rowText += 249; 
				++numOfPixelsColored;
				break;
			}
		}
		c.Y += 1;
		//c.X = 5 * i;
		//c.Y = i + 1;
		//colour(colors[row]);
		g_Console.writeToBuffer(c, rowText, 0x78);
	}
	
	// Writing the enemy location and character to the buffer 
	for (int iEnemyNo = 0, enemyColor, enemyChar; iEnemyNo < g_sEnemy.size(); ++iEnemyNo)
	{
		c.X = g_sEnemy[iEnemyNo].m_cLocation.X;
		c.Y = g_sEnemy[iEnemyNo].m_cLocation.Y + 1;
		// Switch the enemy colour depending on the enemy's health.
		// red when it is full health (3 health), yellow when its at 1 health
		switch (g_sEnemy[iEnemyNo].m_iHealth)
		{
		case 1: enemyColor = 0x76; break; // Yellow
		case 2: enemyColor = 0x7C; break; // Orange
		case 3: enemyColor = 0x74; break; // Red
		}

		switch (g_sEnemy[iEnemyNo].m_iEnemyType)
		{
		case 1: enemyChar = 1; break;  // If enemy's type is 1, set the character to a white smiley 
		case 2: enemyChar = 2; break;  // If enemy's type is 2, set the character to a black smiley 
		case 3: enemyChar = 62; break; // If enemy's type is 3, set the character to a arrow depending on the turret direciton
		case 4: enemyChar = 61; break; // Boss
		}

		g_Console.writeToBuffer(c, enemyChar, enemyColor);
	}

	// Writing the character pistol bullets to the buffer
	for (int iBulletNo = 0; iBulletNo < g_sCharBullets.size(); ++iBulletNo)
	{
		c.X = g_sCharBullets[iBulletNo].m_cLocation.X;
		c.Y = g_sCharBullets[iBulletNo].m_cLocation.Y + 1;
		g_Console.writeToBuffer(c, 9, 0x70);
	}

	// Writing the character shotgun bullets to the buffer
	for (int iBulletNo = 0; iBulletNo < g_sCharShotgunBullets.size(); ++iBulletNo)
	{
		c.X = g_sCharShotgunBullets[iBulletNo].X;
		c.Y = g_sCharShotgunBullets[iBulletNo].Y + 1;
		g_Console.writeToBuffer(c, 15, 0x70);
	}

	// Writing the enemy bullets to the buffer
	for (int iBulletNo = 0; iBulletNo < g_sEnemyBullets.size(); ++iBulletNo)
	{
		c.X = g_sEnemyBullets[iBulletNo].m_cLocation.X;
		c.Y = g_sEnemyBullets[iBulletNo].m_cLocation.Y + 1;
		g_Console.writeToBuffer(c, 4, 0x70);
	}

	// Death animation
	if (enemyDiedTime >= g_dElapsedTime - 5.0)
	{
   		for (int y = enemyDiedPos.Y - 1; y < enemyDiedPos.Y + 2; ++y)
		{
			for (int x = enemyDiedPos.X - 1; x < enemyDiedPos.X + 2; ++x)
			{
				if (enemyDiedPos.X != x || enemyDiedPos.Y != y)
				{
					c.X = x;
					c.Y = y + 1;
					g_Console.writeToBuffer(c, 165, 0x70);
				}
			}
		}
	}

	// Writing the power ups to the buffer
	for (int iPowerUpsNo = 0; iPowerUpsNo < g_sPowerUps.size(); ++iPowerUpsNo)
	{
		switch (g_sPowerUps[iPowerUpsNo].m_ePowerUp)
		{
		case SPEED_UP: g_Console.writeToBuffer(g_sPowerUps[iPowerUpsNo].m_cLocation, 83, 0x70); break;
		case ADD_LIVES: g_Console.writeToBuffer(g_sPowerUps[iPowerUpsNo].m_cLocation, 76, 0x70); break;
		case PAINT_BUCKET: g_Console.writeToBuffer(g_sPowerUps[iPowerUpsNo].m_cLocation, 66, 0x70); break;
		case SHOTGUN: g_Console.writeToBuffer(g_sPowerUps[iPowerUpsNo].m_cLocation, 87, 0x70); break;
		}
	}

	// Writes the 2 portals to the buffer
	g_Console.writeToBuffer(g_cPortals[0], 80, 0x70);
	g_Console.writeToBuffer(g_cPortals[1], 80, 0x70);
	
	// If either everything except 1 square is filled and the character is standing on an empty space, the player has won
	if (numOfPixelsColored == g_iNumOfEmptySpace && g_iMap[g_sChar.m_cLocation.Y - 1][g_sChar.m_cLocation.X] == 10)
	{
		g_eGameState = S_WIN;

		double highScore = g_dElapsedTime;
		// highScoreNum the place of the high score,
		// e.g. when highScoreNum is 0, it is the highScore 1st highScore
		int highScoreNum = 4;
		bool highScoreChanged = false;

		// Storing and sorting the new high scores
		for (; highScoreNum >= 0; --highScoreNum)
		{
			if (g_dhighScores[g_iLevelNum][highScoreNum] > highScore || g_dhighScores[g_iLevelNum][highScoreNum] == 0)
			{
				if (highScoreNum < 4)
				{
					g_dhighScores[g_iLevelNum][highScoreNum + 1] = g_dhighScores[g_iLevelNum][highScoreNum];
				}
				highScoreChanged = true;
			}
			// If the current high score is lower than the high score in highScoreNum, exit the loop
			else
			{
				break;
			}
		}

		if (highScoreChanged)
		{
			g_dhighScores[g_iLevelNum][highScoreNum + 1] = highScore;
		}
	}
}

void renderCharacter()
{
	// Draw the location of the character
	WORD charColor = 0x0C;
	if (g_sChar.m_bActive)
	{
		charColor = 0x0A;
	}
	g_Console.writeToBuffer(g_sChar.m_cLocation, (char)12, 0x75);
}

void renderFramerate()
{
	COORD c;
	std::string sHpBar = "";
	std::string sWeapon;
	std::string sSpeedUps;

	// displays the framerate
	std::ostringstream ss;
	ss << std::fixed << std::setprecision(3);
	ss << 1.0 / g_dDeltaTime << "fps";
	c.X = g_Console.getConsoleSize().X - 9;
	c.Y = 0;
	g_Console.writeToBuffer(c, ss.str());

	// If the game state is not the game, return the function so that the code below does not run
	if (g_eGameState != S_GAME)
	{
		return;
	}

	if (g_sChar.m_bHasSpeedUp)
	{
		sSpeedUps = "Increased speed!";
	}
	else
	{
		sSpeedUps = "None";
	}

	// Information is on the top of the map
	// displays the elapsed time, player's coordinates, player's lives, player's powerups at the top of the screen
	if (g_iLevelNum == 1 || g_iLevelNum == 2 || g_iLevelNum == 3)
	{
		ss.str("");
		ss << "Time : " << g_dElapsedTime << "secs"											// Elapsed time
			<< "   Coordinates:" << g_sChar.m_cLocation.X << ", " << g_sChar.m_cLocation.Y  // Player's coordinates
			<< "   Speed-up: " << sSpeedUps 												// Player's powerups
			<< "   Paint: " << g_sChar.m_iPaint;
	}
	c.X = 0;
	c.Y = 0;
	g_Console.writeToBuffer(c, ss.str(), 0x70);

	for (int health = 0; health < g_sChar.m_iHealth; ++health)
	{
		sHpBar += 3;
	}

	switch (g_sChar.m_eWeapon)
	{
	case S_PISTOL:  sWeapon = "Pistol";  break;
	case S_SHOTGUN: sWeapon = "Shotgun"; break;
	}

	// Information is below map
	//displays the players hp bar at the bottom of the screen
	ss.str("");
	ss << "Health : [" << sHpBar << "]"					// Player's Health Bar
		<< "   Curret weapon: " << sWeapon				// Player's weapon
		<< "   Shotgun ammo: " << g_sChar.m_iShotgunAmmo;  // Player's shotgun ammo
	c.X = 0;
	c.Y = 25;
	g_Console.writeToBuffer(c, ss.str(), 0x70);

	
	// Showing what the symbols represent
	ss.str("");
	ss << "Symbols:";
	c.X = g_iWidthOfMap + 1;
	c.Y = 3;
	g_Console.writeToBuffer(c, ss.str(), 0x70);

	ss.str("");
	ss << "P: Portal";
	++c.Y;
	g_Console.writeToBuffer(c, ss.str(), 0x70);

	ss.str("");
	ss << "W: Shotgun ammo";
	++c.Y;
	g_Console.writeToBuffer(c, ss.str(), 0x70);

	ss.str("");
	ss << "S: Speed up";
	++c.Y;
	g_Console.writeToBuffer(c, ss.str(), 0x70);

	ss.str("");
	ss << "B: Paint bucket";
	++c.Y;
	g_Console.writeToBuffer(c, ss.str(), 0x70);

	ss.str("");
	ss << "L: Add lives";
	++c.Y;
	g_Console.writeToBuffer(c, ss.str(), 0x70);
}

bool checkCoordinates(int _inputX, int _inputY)
{
	//checks if players coordinates are the same as those passed through 
	if (_inputX == g_sChar.m_cLocation.X && _inputY == g_sChar.m_cLocation.Y)
	{
		return true;
	}
	else
	{
		return false;
	}
}

// Returns the character in the position
// Parameter gets the position using the cartesian coordinates (x,y) not (row,column)
int getCharInMap(COORD _position)
{
	return g_iMap[_position.Y][_position.X];
}

void moveBullets()
{
	COORD c;
	
	// If the bullet never hit any enemy then the value will be 0
	// If the bullet hit the first enemy then the value will be 1
	int iEnemyNoDied = 0; 

	bool bulletHitEnemy = false;

	for (int iBulletNo = 0; iBulletNo < g_sCharBullets.size(); ++iBulletNo)
	{
		if (g_sCharBullets[iBulletNo].m_dBounceTime > g_dElapsedTime)
			continue;

		c = g_sCharBullets[iBulletNo].m_cLocation;
		switch (g_sCharBullets[iBulletNo].m_eDirection)
		{
		case S_UP:
			c.Y--;

			// If the bullet hit the enemy
			if (ifBulletHitEnemy(c, 1) > 0)
			{
				bulletHitEnemy = true;
				break;
			}

			// If the next position of the bullet is a wall
			else if (getCharInMap(c) == 1)
			{
				g_sCharBullets.erase(g_sCharBullets.begin() + iBulletNo); // deleting the bullet
				--iBulletNo; // Minus one becuase the bullet was erased so the next bullet will have the same index as this one.
				continue;
			}
			else
			{
				g_sCharBullets[iBulletNo].m_cLocation.Y = c.Y;
			}
			break;
		case S_DOWN:
			++c.Y;
			
			if (ifBulletHitEnemy(c, 1) > 0)
			{
				bulletHitEnemy = true;
				break;
			}
			
			else if (getCharInMap(c) == 1)
			{
				g_sCharBullets.erase(g_sCharBullets.begin() + iBulletNo);
				--iBulletNo;
				continue;
			}
			else
			{
				g_sCharBullets[iBulletNo].m_cLocation.Y = c.Y;
			}
			break;
		case S_LEFT:
			--c.X;
			if (ifBulletHitEnemy(c, 1) > 0)
			{
				bulletHitEnemy = true;
				break;
			}
			else if (getCharInMap(c) == 1)
			{
				g_sCharBullets.erase(g_sCharBullets.begin() + iBulletNo);
				--iBulletNo;
				continue;
			}
			else
			{
				g_sCharBullets[iBulletNo].m_cLocation.X = c.X;
			}
			break;
		case S_RIGHT:
			++c.X;
			if (ifBulletHitEnemy(c, 1) > 0)
			{
				bulletHitEnemy = true;
				break;
			}
			else if (getCharInMap(c) == 1)
			{
				g_sCharBullets.erase(g_sCharBullets.begin() + iBulletNo);
				--iBulletNo;
				continue;
			}
			else
			{
				g_sCharBullets[iBulletNo].m_cLocation.X = c.X;
			}
			break;
		}

		// Continuing the code when the bullet touch the enemy
		// If the enemy is dead means that the bullet hit the enemy
		if (bulletHitEnemy)
		{
			g_sCharBullets.erase(g_sCharBullets.begin() + iBulletNo); // deleting the bullet
			--iBulletNo; // Minus one becuase the bullet was erased so the next bullet will have the same index as this one.
		}
		else
		{
			g_sCharBullets[iBulletNo].m_dBounceTime = g_dElapsedTime + 0.1;
		}
	}

	// Moving the enemy's bullet
	for (int iBulletNo = 0; iBulletNo < g_sEnemyBullets.size(); ++iBulletNo)
	{
		if (g_sEnemyBullets[iBulletNo].m_dBounceTime > g_dElapsedTime)
			continue;

		switch (g_sEnemyBullets[iBulletNo].m_eDirection)
		{
		case S_UP:    --g_sEnemyBullets[iBulletNo].m_cLocation.Y; break;
		case S_DOWN:  ++g_sEnemyBullets[iBulletNo].m_cLocation.Y; break;
		case S_LEFT:  --g_sEnemyBullets[iBulletNo].m_cLocation.X; break;
		case S_RIGHT: ++g_sEnemyBullets[iBulletNo].m_cLocation.X; break;
		case S_NORTHEAST:
			++g_sEnemyBullets[iBulletNo].m_cLocation.X;
			--g_sEnemyBullets[iBulletNo].m_cLocation.Y;
			break;
		case S_NORTHWEST:
			--g_sEnemyBullets[iBulletNo].m_cLocation.X;
			--g_sEnemyBullets[iBulletNo].m_cLocation.Y;
			break;
		case S_SOUTHEAST:
			++g_sEnemyBullets[iBulletNo].m_cLocation.X;
			++g_sEnemyBullets[iBulletNo].m_cLocation.Y;
			break;
		case S_SOUTHWEST:
			--g_sEnemyBullets[iBulletNo].m_cLocation.X;
			++g_sEnemyBullets[iBulletNo].m_cLocation.Y;
			break;
		}

		// If after moving the bullet and the bullet's location is the same as the character's, delete the bullet and minus one health to the player
		if (g_sEnemyBullets[iBulletNo].m_cLocation.X == g_sChar.m_cLocation.X && g_sEnemyBullets[iBulletNo].m_cLocation.Y + 1== g_sChar.m_cLocation.Y)
		{
			--g_sChar.m_iHealth;
			if (g_sChar.m_iHealth <= 0)
			{
				g_eGameState = S_LOSE;
			};
			g_sEnemyBullets.erase(g_sEnemyBullets.begin() + iBulletNo);
		}
		// If the bullet hit a wall
		else if (g_iMap[g_sEnemyBullets[iBulletNo].m_cLocation.Y][g_sEnemyBullets[iBulletNo].m_cLocation.X] == 1)
		{
			g_sEnemyBullets.erase(g_sEnemyBullets.begin() + iBulletNo);
		}
		else
		{
			g_sEnemyBullets[iBulletNo].m_dBounceTime = g_dElapsedTime + 0.1;
		}
	}
}

// If the bullet never hit the enemy                return 0
// If the bullet hit the enemy but never kill       return 1
// If the bullet hit the enemy and kills the enemy, return 2
int ifBulletHitEnemy(COORD _cBulletCOORD, int _dmg)
{
	for (int iEnemyNo = 0; iEnemyNo < g_sEnemy.size(); ++iEnemyNo)
	{
		if (g_sEnemy[iEnemyNo].m_cLocation.X == _cBulletCOORD.X && g_sEnemy[iEnemyNo].m_cLocation.Y == _cBulletCOORD.Y)
		{
			g_sEnemy[iEnemyNo].m_iHealth -= _dmg;

			if (g_sEnemy[iEnemyNo].m_iHealth == 0)
			{
				enemyDiedPos = g_sEnemy[iEnemyNo].m_cLocation;
				enemyDiedTime = g_dElapsedTime;
				g_sEnemy.erase(g_sEnemy.begin() + iEnemyNo);
				return 2; // Bullet hit and kill enemy
			}
			return 1; // Bullet hit but does not kill enemy
		}
	}

	return 0; // Bullet does not hit
}

void renderToScreen()
{
	// Writes the buffer to the console, hence you will see what you have written
	g_Console.flushBufferToConsole();
}