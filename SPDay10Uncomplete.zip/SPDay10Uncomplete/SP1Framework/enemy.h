#ifndef _ENEMY_H
#define _ENEMY_H

#include "general.h"
#include "game.h"

extern double  g_dElapsedTime;

extern int g_iMap[24][73];
extern int g_iLevelNum; // shows the game level

extern EGAMESTATES g_eGameState;

void moveEnemy();
bool ifEnemySeePlayer(int _enemyNo);
void enemyPistolAttack(int _enemyNo);
void spawnEnemy();

#endif // _ENEMY_H