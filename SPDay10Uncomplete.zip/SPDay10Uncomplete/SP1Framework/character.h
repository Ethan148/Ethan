#ifndef _CHARACTER_H
#define _CHARACTER_H

#include <vector>

extern double  g_dElapsedTime;
extern double  g_dBounceTime; // this is to prevent key bouncing, so we won't trigger keypresses more than once

extern bool    g_abKeyPressed[K_COUNT];

extern int g_iMap[24][73];

extern std::vector<SGameEnemy> g_sEnemy;
extern std::vector<SBullet> g_sEnemyBullets;
extern std::vector<SPowerUp> g_sPowerUps;

extern EGAMESTATES g_eGameState;

extern COORD g_cPortals[2]; // Stores the location of the portals

extern int g_iNumOfEmptySpace; // stores the number of empty spaces in the original map file

void shotgunAttack(); // Code for the shotgun attack
int getCharInMap(COORD _position); // Returns the character in the position in map 1
void charPistolAttack();
int ifBulletHitEnemy(COORD _cBulletCOORD, int _dmg);
bool ifEnemySeePlayer(int _enemyNo);
void enemyPistolAttack(int _enemyNo);

#endif // _CHARACTER_H
