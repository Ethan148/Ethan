#include "enemy.h"
#include <iostream>

std::vector<SGameEnemy> g_sEnemy;
std::vector<SBullet> g_sEnemyBullets;
double g_dBounceTimeEnemy;
double g_dBounceTimeSpawn;

void moveEnemy()
{
	if (g_dBounceTimeEnemy > g_dElapsedTime)
		return;

	for (int i = 0; i < g_sEnemy.size(); ++i)
	{
		// If the enemy is a type 3 enemy 
		// Skip the movement and just shoot
		if (g_sEnemy[i].m_iEnemyType == 3)
		{
			if (g_sEnemy[i].m_dFireTime <= g_dElapsedTime)
			{
				g_sEnemy[i].m_dFireTime = g_dElapsedTime + 0.8;
				enemyPistolAttack(i);
			}
			
			continue;
		}
		else if (g_sEnemy[i].m_iEnemyType == 4)
		{
			if (g_sEnemy[i].m_dFireTime <= g_dElapsedTime)
			{
				g_sEnemy[i].m_dFireTime = g_dElapsedTime + 0.8;
				// firing 8 bullets in all 8 directions
				SBullet sBullet;
				for (int iBullet = 0; iBullet < 8; ++iBullet)
				{
					sBullet.m_cLocation = g_sEnemy[i].m_cLocation;
					sBullet.m_dBounceTime = g_dElapsedTime;
					sBullet.m_eDirection = (EDIRECIONS)iBullet;
					g_sEnemyBullets.push_back(sBullet);
				}
			}
			continue;
		}
		
		int x;

		bool isWall = true;
		while (isWall)
		{
			x = 1 + std::rand() / ((RAND_MAX + 1u) / 4);
			switch (x)
			{
			case 1:
				if (g_iMap[g_sEnemy[i].m_cLocation.Y + 1][g_sEnemy[i].m_cLocation.X] == 1)
				{
					break;
				}
				g_sEnemy[i].m_cLocation.Y++; // Moving enemy Down
				isWall = false;
				break;
			case 2:
				if (g_iMap[g_sEnemy[i].m_cLocation.Y][g_sEnemy[i].m_cLocation.X + 1] == 1)
				{
					break;
				}
				g_sEnemy[i].m_cLocation.X++; // Moving enemy Right
				isWall = false;
				break;
			case 3:
				if (g_iMap[g_sEnemy[i].m_cLocation.Y][g_sEnemy[i].m_cLocation.X - 1] == 1)
				{
					break;
				}
				g_sEnemy[i].m_cLocation.X--; // Moving enemy Left
				isWall = false;
				break;
			case 4:
				if (g_iMap[g_sEnemy[i].m_cLocation.Y - 1][g_sEnemy[i].m_cLocation.X] == 1)
				{
					break;
				}
				g_sEnemy[i].m_cLocation.Y--; // Moving enemy Up
				isWall = false;
				break;
			}
		}

		// If the enemy is type 2,
		// and fired more than 0.8 seconds before it last fired,
		// and the enemy saw the player,
		// Shoot a bullet
		if (g_sEnemy[i].m_iEnemyType == 2 && g_sEnemy[i].m_dFireTime <= g_dElapsedTime && ifEnemySeePlayer(i))
		{
			g_sEnemy[i].m_dFireTime = g_dElapsedTime + 0.8;
			enemyPistolAttack(i);
		}
	}

	// If the enemy touch the character, minus one health for the character
	for (int iEnemyNo = 0; iEnemyNo < g_sEnemy.size(); ++iEnemyNo)
	{
		if (g_sEnemy[iEnemyNo].m_cLocation.X == g_sChar.m_cLocation.X && g_sEnemy[iEnemyNo].m_cLocation.Y + 1 == g_sChar.m_cLocation.Y)
		{
			--g_sChar.m_iHealth;
			if (g_sChar.m_iHealth <= 0)
			{
				g_eGameState = S_LOSE;
			}
		}
	}

	if (g_iLevelNum == 4 && g_dBounceTimeSpawn < g_dElapsedTime)
	{
		spawnEnemy();
		g_dBounceTimeSpawn = g_dElapsedTime + 8.0;
	}

	g_dBounceTimeEnemy = g_dElapsedTime + 0.125;
}

void spawnEnemy()
{
	SGameEnemy sEnemy;
	bool isWall = true;

	while (isWall)
	{
		sEnemy.m_cLocation.X = std::rand() / ((RAND_MAX + 1u) / 69);
		sEnemy.m_cLocation.Y = std::rand() / ((RAND_MAX + 1u) / 24);

		if (g_iMap[sEnemy.m_cLocation.Y][sEnemy.m_cLocation.X] == 0)
		{
			isWall = false;
		}
	}

	sEnemy.m_eDirection = S_UP; // Set the default direction of the enemy to be up
	sEnemy.m_iEnemyType = std::rand() / ((RAND_MAX + 1u) / 2) + 1;
	sEnemy.m_bActive = false;
	g_sEnemy.push_back(sEnemy);
}

// Player loses if they are 'seen' by the police
// When either their x or y position is the same as the police and there is no wall between them, then they lose
bool ifEnemySeePlayer(int _enemyNo)
{
	if (g_sEnemy[_enemyNo].m_cLocation.X == g_sChar.m_cLocation.X)
	{
		int biggerCoordsY, smallerCoordsY;
		bool bHaveWall = false;

		// Get the bigger and smaller coordinates Y for the enemy and the character
		if (g_sEnemy[_enemyNo].m_cLocation.Y + 1 > g_sChar.m_cLocation.Y)
		{
			// if the enemy is above the player, set the enemy's direction to down
			biggerCoordsY = g_sEnemy[_enemyNo].m_cLocation.Y;
			smallerCoordsY = g_sChar.m_cLocation.Y;
			g_sEnemy[_enemyNo].m_eDirection = S_UP;
		}
		else
		{
			smallerCoordsY = g_sEnemy[_enemyNo].m_cLocation.Y;
			biggerCoordsY = g_sChar.m_cLocation.Y;
			g_sEnemy[_enemyNo].m_eDirection = S_DOWN;
		}

		// Check if there's a wall between the enemy and the character (vertically)
		for (int iPos = smallerCoordsY; iPos < biggerCoordsY; ++iPos)
		{
			if (g_iMap[iPos][g_sChar.m_cLocation.X] == 1)
			{
				g_sEnemy[_enemyNo].m_bActive = false;
				return false;
			}
		}

		// If there was no wall between the enemy and the player,
		g_sEnemy[_enemyNo].m_bActive = true;
		return true;
	}
	else if (g_sEnemy[_enemyNo].m_cLocation.Y + 1 == g_sChar.m_cLocation.Y)
	{
		int biggerCoords, smallerCoords;
		bool bHaveWall = false;

		// Get the bigger and smaller coordinates Y for the enemy and the character
		if (g_sEnemy[_enemyNo].m_cLocation.X > g_sChar.m_cLocation.X)
		{
			biggerCoords = g_sEnemy[_enemyNo].m_cLocation.X;
			smallerCoords = g_sChar.m_cLocation.X;
			g_sEnemy[_enemyNo].m_eDirection = S_LEFT;
		}
		else
		{
			smallerCoords = g_sEnemy[_enemyNo].m_cLocation.X;
			biggerCoords = g_sChar.m_cLocation.X;
			g_sEnemy[_enemyNo].m_eDirection = S_RIGHT;
		}

		// Check if there's a wall between the enemy and the character (horizontally)
		for (int i = smallerCoords; i < biggerCoords; ++i)
		{
			if (g_iMap[g_sChar.m_cLocation.Y - 1][i] == 1)
			{
				g_sEnemy[_enemyNo].m_bActive = false;
				return false;
			}
		}

		// If there was no wall between the enemy and the player,
		g_sEnemy[_enemyNo].m_bActive = true;
		return true;
	}
	return false;
}

void enemyPistolAttack(int _enemyNo)
{
	SBullet sBullet;
	// Set the starting location as the enemy's position
	sBullet.m_cLocation.X = g_sEnemy[_enemyNo].m_cLocation.X;
	sBullet.m_cLocation.Y = g_sEnemy[_enemyNo].m_cLocation.Y;

	switch (g_sEnemy[_enemyNo].m_eDirection)
	{
	case S_UP:    sBullet.m_eDirection = S_UP;    break;
	case S_DOWN:  sBullet.m_eDirection = S_DOWN;  break;
	case S_LEFT:  sBullet.m_eDirection = S_LEFT;  break;
	case S_RIGHT: sBullet.m_eDirection = S_RIGHT; break;
	}

	sBullet.m_dBounceTime = g_dElapsedTime;

	g_sEnemyBullets.push_back(sBullet);
}
