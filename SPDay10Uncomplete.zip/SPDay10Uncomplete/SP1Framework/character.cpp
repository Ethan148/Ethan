#include "general.h"
#include "character.h"

SGameChar   g_sChar;
int g_iShotgunLayer = 0;
std::vector<SBullet> g_sCharBullets;
std::vector<COORD> g_sCharShotgunBullets;

// for shotgun
// if the first bullet in the shot for the second layer has hit a wall, then the first element in the array is 1
bool isWallInSecondLayer[3] = {};

// Stores the time when the gun fires a shot
double g_dGunFireTime;

// Stores the number of bullets that the gun has
int g_iShotgunBullet, g_iPistolBullet;

void moveCharacter()
{
	bool bSomethingHappened = false;
	COORD originalCoords = g_sChar.m_cLocation;
	if (g_dBounceTime > g_dElapsedTime)
		return;
	// Stop the character movement if the character is shooting
	else if (g_iShotgunLayer != 0)
	{
		++g_iShotgunLayer;
		shotgunAttack();
		g_dBounceTime = g_dElapsedTime + 0.3;
		
		// the 4th shotgunLayer is clearing the shotgun bullets so the player still can move
		if (g_iShotgunLayer != 4)
		{
			return;
		}
	}

	// Updating the location of the character based on the key press
	// providing a beep sound whenver we shift the character
	if (g_abKeyPressed[K_UP] && g_iMap[g_sChar.m_cLocation.Y - 2][g_sChar.m_cLocation.X] != 1)
	{
		//Beep(1440, 30);
		g_sChar.m_cLocation.Y--;
		bSomethingHappened = true;
		g_sChar.m_eDirection = S_UP;
	}
	if (g_abKeyPressed[K_LEFT] && g_iMap[g_sChar.m_cLocation.Y - 1][g_sChar.m_cLocation.X - 1] != 1)
	{
		//Beep(1440, 30);
		g_sChar.m_cLocation.X--;
		bSomethingHappened = true;
		g_sChar.m_eDirection = S_LEFT;
	}
	if (g_abKeyPressed[K_DOWN] && g_iMap[g_sChar.m_cLocation.Y][g_sChar.m_cLocation.X] != 1)
	{
		//Beep(1440, 30);
		g_sChar.m_cLocation.Y++;
		bSomethingHappened = true;
		g_sChar.m_eDirection = S_DOWN;
	}
	if (g_abKeyPressed[K_RIGHT] && g_iMap[g_sChar.m_cLocation.Y - 1][g_sChar.m_cLocation.X + 1] != 1)
	{
		//Beep(1440, 30);
		g_sChar.m_cLocation.X++;
		bSomethingHappened = true;
		g_sChar.m_eDirection = S_RIGHT;
	}
	// If the player press space and there was a 1.5 second difference between the previous time he pressed, do nothing because of the gun cooldown
	if (g_abKeyPressed[K_SPACE] && g_dGunFireTime < g_dElapsedTime)
	{
		g_sChar.m_bActive = !g_sChar.m_bActive;
		switch (g_sChar.m_eWeapon)
		{
		case S_PISTOL:
			g_dGunFireTime = g_dElapsedTime + 0.8;
			charPistolAttack();
			break;
		case S_SHOTGUN:
			if (g_sChar.m_iShotgunAmmo > 0)
			{
				g_dGunFireTime = g_dElapsedTime + 1.5;
				++g_iShotgunLayer;
				--g_sChar.m_iShotgunAmmo;
				shotgunAttack();
				PlaySound(TEXT("shotgunSound.wav"), NULL, SND_ASYNC);
			}
			
			break;
		}
		bSomethingHappened = true;
	}
	if (g_abKeyPressed[K_ONE])
	{
		g_sChar.m_eWeapon = S_PISTOL;
	}
	if (g_abKeyPressed[K_TWO])
	{
		g_sChar.m_eWeapon = S_SHOTGUN;
	}
	if (bSomethingHappened)
	{
		// If the character touch the enemy, minus one health for the character
		for (int iEnemyNo = 0; iEnemyNo < g_sEnemy.size(); ++iEnemyNo)
		{
			if (g_sEnemy[iEnemyNo].m_cLocation.X == g_sChar.m_cLocation.X && g_sEnemy[iEnemyNo].m_cLocation.Y + 1 == g_sChar.m_cLocation.Y)
			{
				--g_sChar.m_iHealth;
				if (g_sChar.m_iHealth <= 0)
				{
					g_eGameState = S_LOSE;
				}
			}
		}

		for (int iEnemyNo = 0; iEnemyNo < g_sEnemy.size(); ++iEnemyNo)
		{
			// If the enemy is type 2,
			// and fired more than 0.8 seconds before it last fired,
			// and the enemy saw the player,
			// Shoot a bullet
			if (g_sEnemy[iEnemyNo].m_iEnemyType == 2 && g_sEnemy[iEnemyNo].m_dFireTime <= g_dElapsedTime && ifEnemySeePlayer(iEnemyNo))
			{
				g_sEnemy[iEnemyNo].m_dFireTime = g_dElapsedTime + 0.8;
				enemyPistolAttack(iEnemyNo);
			}
		}

		for (int iPowerUpNo = 0; iPowerUpNo < g_sPowerUps.size(); ++iPowerUpNo)
		{
			if (g_sPowerUps[iPowerUpNo].m_cLocation.X == g_sChar.m_cLocation.X && g_sPowerUps[iPowerUpNo].m_cLocation.Y == g_sChar.m_cLocation.Y)
			{
				switch (g_sPowerUps[iPowerUpNo].m_ePowerUp)
				{
				case SPEED_UP:
					g_sChar.m_bHasSpeedUp = true;
					g_sChar.m_dSpeedUpPickUpTime = g_dElapsedTime;
					break;
				case ADD_LIVES:
					++g_sChar.m_iHealth;
					break;
				case PAINT_BUCKET:
					// There will be 2 paint buckets in every map. 
					// So the player must collect these 2 buckets in order to paint the whole map 
					// as each bucket gives enough paint to paint half the map.
					g_sChar.m_iPaint += g_iNumOfEmptySpace / 2;
					break;
				case SHOTGUN:
					g_sChar.m_iShotgunAmmo += 3;
					break;
				}

				// Take out the power up if the player collected the power up
				g_sPowerUps.erase(g_sPowerUps.begin() + iPowerUpNo);
			}
		}

		// Switching character's position between the 2 portals
		if (g_sChar.m_cLocation.X == g_cPortals[0].X && g_sChar.m_cLocation.Y == g_cPortals[0].Y)
		{
			g_sChar.m_cLocation = g_cPortals[1];
		}
		else if (g_sChar.m_cLocation.X == g_cPortals[1].X && g_sChar.m_cLocation.Y == g_cPortals[1].Y)
		{
			g_sChar.m_cLocation = g_cPortals[0];
		}
		
		// set the bounce time to some time in the future to prevent accidental triggers
		// If the player has the speed up power up, lower the bounce time to allow the character to move more often
		if (g_sChar.m_bHasSpeedUp)
		{
			g_dBounceTime = g_dElapsedTime + 0.02;

			// Set the time limit (5 seconds) for the speed up power up
			// If the time limit is up, make the character not have the speed up power up
			if (g_sChar.m_dSpeedUpPickUpTime < g_dElapsedTime - 5.0)
			{
				g_sChar.m_bHasSpeedUp = false;
			}
		}
		else
		{
			g_dBounceTime = g_dElapsedTime + 0.125;
		}

		// If the player has paint and the player is not on top of paint,
		if (g_sChar.m_iPaint > 0 && g_iMap[g_sChar.m_cLocation.Y - 1][g_sChar.m_cLocation.X] != 10)
		{
			// Put paint on the floor
			g_iMap[g_sChar.m_cLocation.Y - 1][g_sChar.m_cLocation.X] = 10;
			// Minus one from the character's paint
			--g_sChar.m_iPaint;
		}
	}
}

// Shotgun attack (shoot bullets in a triangle (width - 5, height - 3)
// The m_eDirection of the attack is the direction of the player when the player activates the skill
void shotgunAttack()
{
	COORD c = g_sChar.m_cLocation;

	if (g_sChar.m_eDirection == S_UP || g_sChar.m_eDirection == S_DOWN)
	{
		if (g_iShotgunLayer < 4)
		{
			switch (g_sChar.m_eDirection)
			{
			case S_UP: c.Y -= g_iShotgunLayer + 1; break;
			case S_DOWN: c.Y += g_iShotgunLayer - 1; break;
			}
		}

		switch (g_iShotgunLayer)
		{
		case 1:
			// If the bullet hit the enemy
			if (ifBulletHitEnemy(c, 3) > 0)
			{
				// If there is a enemy in front of the player when the player shoots, then cancel the shot (as the wall will block the rest of the bullets)
				g_iShotgunLayer = 0;
			}
			else if (getCharInMap(c) == 0)
			{
				g_sCharShotgunBullets.push_back(c);
			}
			// If there is a wall in front of the player when the player shoots, then cancel the shot (as the wall will block the rest of the bullets)
			else if (getCharInMap(c) == 1)
			{
				g_iShotgunLayer = 0;
			}
			break;
		case 2:
			c.X -= 1;
			for (; c.X < g_sChar.m_cLocation.X + 2; ++c.X)
			{
				if (ifBulletHitEnemy(c, 3) > 0)
				{
					isWallInSecondLayer[c.X - g_sChar.m_cLocation.X + 1] = true;
				}
				else if (getCharInMap(c) == 0)
				{
					g_sCharShotgunBullets.push_back(c);
				}
				else if (getCharInMap(c) == 1)
				{
					isWallInSecondLayer[c.X - g_sChar.m_cLocation.X + 1] = true;
				}
			}
			break;
		case 3:
			c.X -= 2;
			for (; c.X < g_sChar.m_cLocation.X + 3; ++c.X)
			{
				if (isWallInSecondLayer[0] && c.X < g_sChar.m_cLocation.X)
				{
					continue;
				}
				else if (isWallInSecondLayer[1] && c.X == g_sChar.m_cLocation.X)
				{
					continue;
				}
				else if (isWallInSecondLayer[2] && c.X > g_sChar.m_cLocation.X)
				{
					continue;
				}

				// If the bullet never hit the enemy and never hit a wall, add a bullet to g_sCharShotgunBullets
				if (ifBulletHitEnemy(c, 3) == 0 && getCharInMap(c) == 0)
				{
					g_sCharShotgunBullets.push_back(c);
				}
			}
			// Resetting the array
			isWallInSecondLayer[0] = false;
			isWallInSecondLayer[1] = false;
			isWallInSecondLayer[2] = false;
			break;
		case 4: // Removing the bullets
			g_sCharShotgunBullets.clear();
			g_iShotgunLayer = 0;
		}
	}
	else // If the direction of the character is either S_LEFT or S_RIGHT
	{
		if (g_iShotgunLayer < 4)
		{
			switch (g_sChar.m_eDirection)
			{
			case S_LEFT: c.X -= g_iShotgunLayer;  break;
			case S_RIGHT: c.X += g_iShotgunLayer; break;
			}
		}

		switch (g_iShotgunLayer)
		{
		case 1:
			c.Y -= 1;
			if (ifBulletHitEnemy(c, 3) > 0)
			{
				g_iShotgunLayer = 0;
			}
			else if (getCharInMap(c) == 0)
			{
				g_sCharShotgunBullets.push_back(c);
			}
			// If there is a wall in front of the player when the player shoots, then cancel the shot (as the wall will block the rest of the bullets)
			else if (getCharInMap(c) == 1)
			{
				g_iShotgunLayer = 0;
			}
			break;
		case 2:
			c.Y -= 2;
			for (; c.Y < g_sChar.m_cLocation.Y + 1; ++c.Y)
			{
				if (ifBulletHitEnemy(c, 3) > 0)
				{
					isWallInSecondLayer[c.Y - g_sChar.m_cLocation.Y + 2] = true;
				}
				else if (getCharInMap(c) == 0)
				{
					g_sCharShotgunBullets.push_back(c);
				}
				else if (getCharInMap(c) == 1)
				{
					isWallInSecondLayer[c.Y - g_sChar.m_cLocation.Y + 2] = true;
				}
			}
			break;
		case 3:
			c.Y -= 3;
			for (; c.Y < g_sChar.m_cLocation.Y + 2; ++c.Y)
			{
				if (isWallInSecondLayer[0] && c.Y < g_sChar.m_cLocation.Y - 1)
				{
					continue;
				}
				else if (isWallInSecondLayer[1] && c.Y == g_sChar.m_cLocation.Y - 1)
				{
					continue;
				}
				else if (isWallInSecondLayer[2] && c.Y > g_sChar.m_cLocation.Y - 1)
				{
					continue;
				}

				if (ifBulletHitEnemy(c, 3) == 0 && getCharInMap(c) == 0)
				{
					g_sCharShotgunBullets.push_back(c);
				}
			}
			isWallInSecondLayer[0] = false;
			isWallInSecondLayer[1] = false;
			isWallInSecondLayer[2] = false;
			break;
		case 4: // Removing the bullets
			g_sCharShotgunBullets.clear();
			g_iShotgunLayer = 0;
		}
	}
}

void charPistolAttack()
{
	SBullet sBullet;
	// Set the starting location as the character's position
	sBullet.m_cLocation.X = g_sChar.m_cLocation.X;
	sBullet.m_cLocation.Y = g_sChar.m_cLocation.Y - 1;
	
	switch (g_sChar.m_eDirection)
	{
	case S_UP:    sBullet.m_eDirection = S_UP;    break;
	case S_DOWN:  sBullet.m_eDirection = S_DOWN;  break;
	case S_LEFT:  sBullet.m_eDirection = S_LEFT;  break;
	case S_RIGHT: sBullet.m_eDirection = S_RIGHT; break;
	}

	sBullet.m_dBounceTime = g_dElapsedTime;

	g_sCharBullets.push_back(sBullet);
}